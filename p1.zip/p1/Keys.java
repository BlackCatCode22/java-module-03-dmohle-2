package p1;

public class Keys {
    int numOfkeys;
}
